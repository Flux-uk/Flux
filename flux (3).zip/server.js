const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('./db');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // Allows image payloads
app.use(express.static('public'));

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'flux_fallback_secret_key';

// JWT Auth Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Unauthorized access' });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: 'Token invalid or expired' });
        req.user = user;
        next();
    });
}

// 1. SIGNUP & AUTOMATIC STORE CREATION
app.post('/api/auth/signup', async (req, res) => {
    const { email, password, storeName } = req.body;

    if (!email || !password || !storeName) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Generate clean URL slug (e.g. "My Cool Store!" -> "my-cool-store")
        let slug = storeName.toLowerCase().trim().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
        
        // Save User
        const userResult = await pool.query(
            'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id',
            [email, hashedPassword]
        );
        const userId = userResult.rows[0].id;

        // Save Store
        const storeResult = await pool.query(
            'INSERT INTO stores (user_id, name, slug) VALUES ($1, $2, $3) RETURNING id, slug',
            [userId, storeName, slug]
        );

        // Issue JWT Token
        const token = jwt.sign({ userId, storeId: storeResult.rows[0].id }, JWT_SECRET, { expiresIn: '7d' });

        res.status(201).json({
            success: true,
            token,
            slug: storeResult.rows[0].slug
        });
    } catch (err) {
        console.error('Signup Error:', err);
        if (err.code === '23505') { // Unique constraint violation
            return res.status(400).json({ error: 'An account or store with that name already exists.' });
        }
        res.status(500).json({ error: 'Server error creating store.' });
    }
});

// 2. SAVE MERCHANT PAYMENT GATEWAY LINK
app.post('/api/store/setup', authenticateToken, async (req, res) => {
    const { paymentLink } = req.body;

    try {
        await pool.query(
            'UPDATE stores SET payment_link = $1 WHERE user_id = $2',
            [paymentLink, req.user.userId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error('Setup Error:', err);
        res.status(500).json({ error: 'Failed to update store settings.' });
    }
});

// 3. ADD PRODUCT
app.post('/api/products', authenticateToken, async (req, res) => {
    const { title, price, imageUrl } = req.body;

    try {
        await pool.query(
            'INSERT INTO products (store_id, title, price, image_url) VALUES ($1, $2, $3, $4)',
            [req.user.storeId, title, price, imageUrl]
        );

        const storeResult = await pool.query('SELECT slug FROM stores WHERE id = $1', [req.user.storeId]);
        
        res.json({ success: true, slug: storeResult.rows[0].slug });
    } catch (err) {
        console.error('Add Product Error:', err);
        res.status(500).json({ error: 'Failed to save product.' });
    }
});

// 4. GET PUBLIC STORE FRONTEND DATA
app.get('/api/store/:slug', async (req, res) => {
    const { slug } = req.params;

    try {
        const storeResult = await pool.query('SELECT id, name, payment_link FROM stores WHERE slug = $1', [slug]);
        if (storeResult.rows.length === 0) {
            return res.status(404).json({ error: 'Store not found' });
        }

        const store = storeResult.rows[0];
        const productsResult = await pool.query('SELECT * FROM products WHERE store_id = $1 ORDER BY id DESC', [store.id]);

        res.json({
            storeName: store.name,
            paymentLink: store.payment_link,
            products: productsResult.rows
        });
    } catch (err) {
        console.error('Fetch Store Error:', err);
        res.status(500).json({ error: 'Error loading store' });
    }
});

app.listen(PORT, () => {
    console.log(`Flux server live on port ${PORT}`);
});
